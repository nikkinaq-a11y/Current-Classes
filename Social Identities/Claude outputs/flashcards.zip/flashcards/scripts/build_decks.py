#!/usr/bin/env python3
"""Build deck JSON files from the authoring text files.

Authoring format (one card per line):
    Front ||| Back ||| Source ||| tag1,tag2
    @deck id | Title | Description
    @topic Topic name
"""
import glob, json, os, re, sys

SRC = sys.argv[1]
OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)

ABBR = ["e.g.", "i.e.", "vs.", "et al.", "etc.", "Dr.", "No.", "approx.", "St."]

def sentence_count(text):
    t = text
    for a in ABBR:
        t = t.replace(a, a.replace(".", ""))
    t = re.sub(r"\b[A-Z]\.\s?(?=[A-Z])", "X ", t)       # initials like J. C. Turner
    t = re.sub(r"\(\d{4}[a-z]?\)", "(Y)", t)
    parts = re.split(r"(?<=[.!?])[\"')]*\s+(?=[A-Z0-9\"(])", t.strip())
    return len([p for p in parts if p.strip()])

decks, problems, total = [], [], 0
for path in sorted(glob.glob(os.path.join(SRC, "*.txt"))):
    deck, topic, cards = None, "General", []
    seen_fronts = set()
    for ln, raw in enumerate(open(path, encoding="utf-8"), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("@deck"):
            did, title, desc = [x.strip() for x in line[5:].split("|", 2)]
            deck = {"id": did, "title": title, "description": desc, "cards": []}
            continue
        if line.startswith("@topic"):
            topic = line[6:].strip()
            continue
        parts = [p.strip() for p in line.split("|||")]
        if len(parts) != 4:
            problems.append(f"{os.path.basename(path)}:{ln}: expected 4 fields, got {len(parts)}")
            continue
        front, back, source, tags = parts
        n = len(deck["cards"]) + 1
        card = {
            "id": f"{deck['id']}-{n:03d}",
            "term": front,
            "definition": back,
            "topic": topic,
            "source": source,
            "tags": [t.strip() for t in tags.split(",") if t.strip()],
        }
        words = len(back.split())
        sc = sentence_count(back)
        if sc > 3 or words > 55:
            problems.append(f"{card['id']} long: {sc} sentences, {words} words")
        if front in seen_fronts:
            problems.append(f"{card['id']} duplicate front: {front}")
        seen_fronts.add(front)
        deck["cards"].append(card)
    decks.append(deck)
    total += len(deck["cards"])
    with open(os.path.join(OUT, f"{deck['id']}.json"), "w", encoding="utf-8") as f:
        json.dump(deck, f, indent=2, ensure_ascii=False)
        f.write("\n")

index = [{"id": d["id"], "title": d["title"], "description": d["description"],
          "cardCount": len(d["cards"]), "file": f"{d['id']}.json"} for d in decks]
with open(os.path.join(OUT, "decks.json"), "w", encoding="utf-8") as f:
    json.dump(index, f, indent=2, ensure_ascii=False)
    f.write("\n")

print(f"{len(decks)} decks, {total} cards")
for d in decks:
    print(f"  {d['id']:<12} {len(d['cards']):>3}  {d['title']}")
print("PROBLEMS:" if problems else "No problems.")
for p in problems:
    print("  -", p)
